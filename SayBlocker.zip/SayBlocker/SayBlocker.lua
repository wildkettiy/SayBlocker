-- 0. Slash Befehle
SLASH_SAYBLOCKER1 = "/sbl"
SLASH_SAYBLOCKER2 = "/sayblocker"
SlashCmdList["SAYBLOCKER"] = function()
    if SayBlockerMainFrame then
        if SayBlockerMainFrame:IsShown() then SayBlockerMainFrame:Hide() else SayBlockerMainFrame:Show() end
    end
end

-- Variablen
local isBlocking = false
local manualOverride = false
local timeRemaining = 0
local tempAutoWhitelist = {}

local PRESET_EMOTES = {
    { token = "WAVE",      label = "Winken (/wave)" },
    { token = "GREET",     label = "Grüßen (/greet)" },
    { token = "HI",        label = "Hallo (/hi, /hello)" },
    { token = "CHEER",     label = "Jubeln (/cheer)" },
    { token = "DANCE",     label = "Tanzen (/dance)" },
    { token = "BOW",       label = "Verbeugen (/bow)" },
    { token = "KISS",      label = "Kuss (/kiss)" },
    { token = "FLIRT",     label = "Flirten (/flirt)" },
}

-- 1. Datenbank Initialisierung
local function InitializeDB()
    if not SayBlockerDB then SayBlockerDB = {} end
    if not SayBlockerDB.emotes then SayBlockerDB.emotes = { ["WAVE"] = true, ["HI"] = true, ["CHEER"] = true } end
    for _, data in ipairs(PRESET_EMOTES) do
        if SayBlockerDB.emotes[data.token] == nil then SayBlockerDB.emotes[data.token] = false end
    end
    if not SayBlockerDB.whitelist then SayBlockerDB.whitelist = {} end
    if not SayBlockerDB.autoWhitelist then SayBlockerDB.autoWhitelist = { friends = true, guild = true, group = true } end
    if SayBlockerDB.blockBubbles == nil then SayBlockerDB.blockBubbles = false end
    if SayBlockerDB.enabled == nil then SayBlockerDB.enabled = true end
    if SayBlockerDB.reblockDelay == nil then SayBlockerDB.reblockDelay = 60 end
    if SayBlockerDB.minimapPos == nil then SayBlockerDB.minimapPos = 45 end
end

-- 2. Automatisches Vertrauen (Scan)
local function UpdateAutoWhitelist()
    wipe(tempAutoWhitelist)
    if not SayBlockerDB then return end
    for i = 1, GetNumFriends() do 
        local n = GetFriendInfo(i)
        if n then tempAutoWhitelist[n:upper()] = true end 
    end
    if SayBlockerDB.autoWhitelist.guild and IsInGuild() then
        for i = 1, GetNumGuildMembers() do 
            local n = GetGuildRosterInfo(i)
            if n then tempAutoWhitelist[n:upper()] = true end 
        end
    end
    if SayBlockerDB.autoWhitelist.group then
        local numR = GetNumRaidMembers()
        if numR > 0 then
            for i = 1, numR do 
                local n = GetRaidRosterInfo(i)
                if n then tempAutoWhitelist[n:upper()] = true end 
            end
        else
            for i = 1, GetNumPartyMembers() do 
                local n = UnitName("party"..i)
                if n then tempAutoWhitelist[n:upper()] = true end 
            end
        end
    end
end

-- 3. Status Update
local function UpdateBlockingState()
    if not SayBlockerDB then return end
    local currentZone = GetRealZoneText() or ""
    isBlocking = (currentZone == "Dalaran") and SayBlockerDB.enabled and not manualOverride
    if isBlocking and SayBlockerDB.blockBubbles then SetCVar("chatBubbles", 0) else SetCVar("chatBubbles", 1) end
    if SB_MinimapButtonIcon then
        if not SayBlockerDB.enabled then SB_MinimapButtonIcon:SetVertexColor(1, 0.8, 0)
        elseif isBlocking then SB_MinimapButtonIcon:SetVertexColor(1, 0, 0)
        else SB_MinimapButtonIcon:SetVertexColor(0, 1, 0) end
    end
end

-- 4. UI Erstellung
local function CreateUI()
    local f = CreateFrame("Frame", "SayBlockerMainFrame", UIParent)
    f:SetSize(620, 520); f:SetPoint("CENTER"); f:SetFrameStrata("DIALOG")
    f:SetBackdrop({bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border", tile = true, tileSize = 32, edgeSize = 32, insets = { left = 11, right = 12, top = 12, bottom = 11 }})
    f:SetMovable(true); f:EnableMouse(true); f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving); f:SetScript("OnDragStop", f.StopMovingOrSizing); f:Hide()

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton"); close:SetPoint("TOPRIGHT", -5, -5)
    local title = f:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge"); title:SetPoint("TOP", 0, -15); title:SetText("SayBlocker v2.3")

    -- NEU: Header für die linke Seite
    local optHeader = f:CreateFontString(nil, "ARTWORK", "GameFontNormal"); optHeader:SetPoint("TOPLEFT", 25, -50); optHeader:SetText("Addon-Konfiguration:")

    local function NewCB(name, label, x, y, dbTable, dbKey, callback)
        local cb = CreateFrame("CheckButton", "SB_CB_"..name, f, "InterfaceOptionsCheckButtonTemplate")
        cb:SetPoint("TOPLEFT", x, y); _G[cb:GetName().."Text"]:SetText(label)
        cb:SetChecked(dbTable[dbKey])
        cb:SetScript("OnClick", function(self) dbTable[dbKey] = self:GetChecked(); if callback then callback() end end)
        return cb
    end

    NewCB("AddActive", "Addon global aktivieren", 25, -70, SayBlockerDB, "enabled", UpdateBlockingState)
    NewCB("AddBubbles", "Sprechblasen ebenfalls filtern", 25, -95, SayBlockerDB, "blockBubbles", UpdateBlockingState)
    
    local slider = CreateFrame("Slider", "SB_TimeSlider", f, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", 35, -145); slider:SetMinMaxValues(5, 300); slider:SetValueStep(5); slider:SetWidth(200)
    slider:SetValue(SayBlockerDB.reblockDelay)
    _G[slider:GetName().."Text"]:SetText("Chat öffnen für: "..SayBlockerDB.reblockDelay.." Sek.")
    slider:SetScript("OnValueChanged", function(self, val) local v = math.floor(val); SayBlockerDB.reblockDelay = v; _G[self:GetName().."Text"]:SetText("Chat öffnen für: "..v.." Sek.") end)

    local emoteHeader = f:CreateFontString(nil, "ARTWORK", "GameFontNormal"); emoteHeader:SetPoint("TOPLEFT", 25, -190); emoteHeader:SetText("Chat-Trigger durch Emote:")
    for i, data in ipairs(PRESET_EMOTES) do
        local cb = CreateFrame("CheckButton", "SB_Emote_"..data.token, f, "InterfaceOptionsCheckButtonTemplate")
        cb:SetPoint("TOPLEFT", 25, -195 - (i * 25)); _G[cb:GetName().."Text"]:SetText(data.label)
        cb:SetChecked(SayBlockerDB.emotes[data.token]); cb:SetScript("OnClick", function(self) SayBlockerDB.emotes[data.token] = self:GetChecked() end)
    end

    -- Rechte Seite: Auto-Vertrauen
    local awHeader = f:CreateFontString(nil, "ARTWORK", "GameFontNormal"); awHeader:SetPoint("TOPLEFT", 350, -50); awHeader:SetText("Automatisches Vertrauen:")
    NewCB("AWFriends", "Freunde immer erlauben", 350, -70, SayBlockerDB.autoWhitelist, "friends", UpdateAutoWhitelist)
    NewCB("AWGuild", "Gildenmitglieder erlauben", 350, -95, SayBlockerDB.autoWhitelist, "guild", UpdateAutoWhitelist)
    NewCB("AWGroup", "Gruppe / Raid erlauben", 350, -120, SayBlockerDB.autoWhitelist, "group", UpdateAutoWhitelist)

    -- Rechte Seite: Manuelle Whitelist
    local wlHeader = f:CreateFontString(nil, "ARTWORK", "GameFontNormal"); wlHeader:SetPoint("TOPLEFT", 350, -170); wlHeader:SetText("Manuelle Whitelist:")
    local editBox = CreateFrame("EditBox", "SB_WLEdit", f, "InputBoxTemplate")
    editBox:SetSize(180, 30); editBox:SetPoint("TOPLEFT", 350, -195); editBox:SetAutoFocus(false)
    local addBtn = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
    addBtn:SetSize(100, 22); addBtn:SetPoint("TOPLEFT", 350, -225); addBtn:SetText("Hinzufügen")

    local scroll = CreateFrame("ScrollFrame", "SB_WLScroll", f, "UIPanelScrollFrameTemplate")
    scroll:SetSize(200, 180); scroll:SetPoint("TOPLEFT", 350, -260)
    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(180, 1); scroll:SetScrollChild(content)

    local function RefreshWL()
        local children = {content:GetChildren()}
        for _, c in ipairs(children) do c:Hide(); c:SetParent(nil) end
        local names = {}
        for n in pairs(SayBlockerDB.whitelist) do table.insert(names, n) end
        table.sort(names)
        for i, name in ipairs(names) do
            local b = CreateFrame("Button", nil, content)
            b:SetSize(180, 16); b:SetPoint("TOPLEFT", 0, -(i-1)*18)
            local t = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            t:SetPoint("LEFT", 5, 0); t:SetText(name)
            b:SetScript("OnEnter", function() t:SetTextColor(1, 0, 0) end)
            b:SetScript("OnLeave", function() t:SetTextColor(1, 1, 1) end)
            b:SetScript("OnClick", function() SayBlockerDB.whitelist[name] = nil; RefreshWL() end)
        end
    end
    addBtn:SetScript("OnClick", function() local n = editBox:GetText():trim():upper(); if n ~= "" then SayBlockerDB.whitelist[n] = true; editBox:SetText(""); RefreshWL() end end)
    f:SetScript("OnShow", function() RefreshWL(); UpdateAutoWhitelist() end)
end

-- 5. Minimap Button
local function CreateMinimapButton()
    local mm = CreateFrame("Button", "SB_MinimapButton", Minimap)
    mm:SetSize(33, 33); mm:SetFrameLevel(10); mm:SetFrameStrata("HIGH")
    mm:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
    SB_MinimapButtonIcon = mm:CreateTexture(nil, "BACKGROUND")
    SB_MinimapButtonIcon:SetSize(20, 20); SB_MinimapButtonIcon:SetTexture("Interface\\Icons\\Ability_Warrior_ShieldWall"); SB_MinimapButtonIcon:SetPoint("CENTER")
    local border = mm:CreateTexture(nil, "OVERLAY"); border:SetSize(53, 53); border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder"); border:SetPoint("TOPLEFT")
    local function UpdateMapPos() local a = SayBlockerDB.minimapPos; mm:SetPoint("TOPLEFT", Minimap, "TOPLEFT", 52-(80*cos(a)), (80*sin(a))-52) end
    UpdateMapPos()
    mm:RegisterForDrag("LeftButton"); mm:SetMovable(true)
    mm:SetScript("OnDragStart", function(self) self:SetScript("OnUpdate", function()
        local x, y = GetCursorPosition(); local xm, ym = Minimap:GetLeft(), Minimap:GetBottom()
        x = xm - x/Minimap:GetEffectiveScale() + 70; y = y/Minimap:GetEffectiveScale() - ym - 70
        SayBlockerDB.minimapPos = math.deg(math.atan2(y, x)); UpdateMapPos()
    end) end)
    mm:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    mm:RegisterForClicks("AnyUp")
    mm:SetScript("OnClick", function(self, button)
        if button == "RightButton" then if SayBlockerMainFrame:IsShown() then SayBlockerMainFrame:Hide() else SayBlockerMainFrame:Show() end
        else manualOverride = not manualOverride; timeRemaining = manualOverride and SayBlockerDB.reblockDelay or 0; UpdateBlockingState() end
    end)
    mm:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT"); GameTooltip:SetText("SayBlocker Status", 1, 0.82, 0)
        local status = "|cffff0000Dalaran erreicht: Filter ist aktiv.|r"
        if not SayBlockerDB.enabled then status = "|cffff0000Addon deaktiviert|r"
        elseif manualOverride then status = "|cff00ff00Chat offen|r ("..math.ceil(timeRemaining).."s)"
        elseif GetRealZoneText() ~= "Dalaran" then status = "|cff00ff00Filter bereit (Warte auf Dalaran)|r" end
        GameTooltip:AddLine(status, 1, 1, 1, true); GameTooltip:AddLine(" "); GameTooltip:AddLine("|cff00ff00Links:|r Chat öffnen / schließen (Timer)", 1, 1, 1); GameTooltip:AddLine("|cff00ff00Rechts:|r Einstellungen", 1, 1, 1); GameTooltip:Show()
    end)
    mm:SetScript("OnLeave", function() GameTooltip:Hide() end)
end

-- 6. Filter & Events
ChatFrame_AddMessageEventFilter("CHAT_MSG_SAY", function(self, event, msg, sender)
    if not isBlocking then return false end
    local name = sender:match("([^%-]+)"):upper()
    if SayBlockerDB.whitelist[name] or tempAutoWhitelist[name] then return false end
    return true
end)

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED"); loader:RegisterEvent("ZONE_CHANGED_NEW_AREA"); loader:RegisterEvent("PLAYER_ENTERING_WORLD")
loader:RegisterEvent("FRIENDLIST_UPDATE"); loader:RegisterEvent("GUILD_ROSTER_UPDATE"); loader:RegisterEvent("RAID_ROSTER_UPDATE")
loader:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == "SayBlocker" then InitializeDB(); CreateUI(); CreateMinimapButton(); UpdateAutoWhitelist(); UpdateBlockingState()
    elseif event:find("UPDATE") then UpdateAutoWhitelist() else UpdateBlockingState() end
end)

-- 7. Hooks
local oDoEmote = DoEmote
DoEmote = function(token, ...)
    if isBlocking and SayBlockerDB and SayBlockerDB.emotes[token:upper()] then manualOverride = true; timeRemaining = SayBlockerDB.reblockDelay; UpdateBlockingState() end
    return oDoEmote(token, ...)
end
local tf = CreateFrame("Frame")
tf:SetScript("OnUpdate", function(self, elap) if manualOverride and timeRemaining > 0 then timeRemaining = timeRemaining - elap; if timeRemaining <= 0 then manualOverride = false; UpdateBlockingState() end end end)